﻿namespace Physiotool.Application.Infrastructure
{
    internal class OpeningHours
    {
        
    }
}
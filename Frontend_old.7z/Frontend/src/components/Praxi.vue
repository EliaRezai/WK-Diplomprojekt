<template>
  <h1>PRAXIS</h1>
</template>
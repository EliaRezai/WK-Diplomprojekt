<template>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://www.ionos.at/digitalguidepath/to/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-
  awesome/4.7.0/css/font-awesome.min.css">
  <div class="sub-header">
    <nav>
      <a href="HelloWorld.vue">
        <img src="@/assets/gros.png">
      </a>
      <div class="nav-links" id="navLinks">
        <i class="fa fa-times" onclick="hideMenu()"></i>        
        <ul>
          <li>
            <a href="">Startseite</a>
          </li>
          <li>
            <a href="Praxi.vue">Praxis</a>
          </li>
          <li>
            <a href="">Therapien</a>
          </li>
          <li>
            <a href="">Öffnungszeiten</a>
          </li>
          <li>
            <a href="">Termine</a>
          </li>
          <li>
            <a href="">Login</a>
          </li>
        </ul>
      </div>
      <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
    <div class="text-box">
      <h1>Therapie</h1>
    </div>
    
  </div>

 <!---------- Therapie Seite ----->
 
 <div class="about-us"> 

  <div class="row">
    <div class="a-col">
     <h1>Herzlich Willkommen bei uns!</h1> 
    <p> Es gibt ein paar Fälle, in denen Du Text aus einer Bilddatei <br/>
      extrahieren wollen würdest. Welches Dateiformat Dein Bild hat, s<br/>
      pielt hier keine Rolle, Du kannst einfach aus JPG, PNG, TIF, WEBP und mehr konvertieren.</p>
      <br/>
    <a href="" class="hero-btn red-btn">Mehr Erfahren</a>
    
  </div>
  
  </div>

 </div>


 <div class="h">
 
  <img src="@/assets/77.jpg">
  <img src="@/assets/44.jpg">
  <img src="@/assets/66.jpg">
  <img src="@/assets/77.jpg">
  <img src="@/assets/66.jpg">
  <img src="@/assets/77.jpg">
  <img src="@/assets/44.jpg">
  <img src="@/assets/44.jpg">


 </div>

 <br/>
 
 

 <div class="container2">
  <h2>Suche dein Passender Traphie aus</h2>
  <div class="price-row">
    <div class="price-col">
      <p>Packet 1</p>
      <h3>70€ <span>/ Sitzung</span></h3>
      <ul>
        <li>
          Professionelle Massage
        </li>
        <li>
          Die Rückenmassage
        </li>
        <li>
          Die Sportmassage
        </li>
        <li>
        Triggerpunktmassage
        </li>
        <li>
          Die klassische Massage
        </li>
        <li>
          Die Lymphdrainage
        </li>
      </ul>
      <button>Buchen</button>

    </div>
    <div class="price-col">
      <p>Packet 2</p>
      <h3>150€ <span>/ Sitzung</span></h3>
      <ul>
        <li>
          Osteopathie 
        </li>
        <li>
          Das Muskuloskelettale 

        </li>
        <li>
          Das Viscerale System

        </li>
        <li>
          Das Craniosacrale 
        </li>
        <li>
          45 - Sitzungen

        </li>
        <li>
        </li>
      </ul>
      <button>Buchen</button>
    </div>
   <div class="price-col">
      <p>Packet 3</p>
      <h3>250€ <span>/ Sitzung</span></h3>
      <ul>
        <li>
          Personal Training 
        </li>
        <li>
          Muskelaufbau
        </li>
        <li>
          Konditionstraining
        </li>
        <li>
          Koordinationstraining
        </li>
        <li>
          45 Minuten
        </li>
        <li>
          
        </li>
      </ul>
      <button>Buchen</button>

    </div>


  </div>
 </div>
 
 <div class="c1">
  <div class="t">
   <br/> 
    <div class="tt">
      <div class="ut active-text">
        <span>"</span>
        <p>
          Lorem ipsum dolor situisiqua ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te

        </p>
        <span>Elia Rezai</span>
      </div>

      <div class="ut">
        <p>
          Top ausgestattete Praxis, sehr nettw Atmosphäre, unkomplizierte Terminvereinbarungen
          sowie auch gezielte Übungen genau angepasst an den Bedürfnissen meiner Verletzungen. Nach bereits 5
          Einheiten hatte ich keine Schmerzen mehr!

        </p>
        <span>Elia Rezai</span>
      </div>

      <div class="ut">
        <p>
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te

        </p>
        <span>Elia Rezai</span>
      </div>

      <div class="ut">
        <p>
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te

        </p>
        <span>Elia Rezai</span>
      </div>

      <div class="ut">
        <p>
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te

        </p>
        <span>Elia Rezai</span>
      </div>

    </div>
    <div class="pic">
      <img src="@/assets/100.jpg" class="user-pic active-pic">
    </div>
  </div>
 </div>

<div class="footer">
  <div class="col-1">
    <h3>USEFUL LIKS</h3>
    <a href="#">About</a>
    <a href="#">About</a>
    <a href="#">About</a>
    <a href="#">About</a>
    
  </div>

  <div class="col-2">
    <h3>NEWSLETTER</h3>
    <form>
      <input type="email" placeholder = "Ihre Email Adresse" required>
      <br/>
      <button type="submit">Senden</button>
    </form>
  </div>

  <div class="col-3">
    <h3>
      Kontakte
    </h3> 

    <p>
      123, xyz Road, 3 <br> 1220 Wien Österreich
      <br> +43 676 12345678
    </p>

  </div>
</div>
</template>

<script>

export default {
  name: 'HelloWorld', 
  components:{
  },

}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
*{
  margin: 0;
  padding: 0;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.header {
  min-height: 100vh ;
  width: 100%;
  background-image: linear-gradient(rgba(4,9,30,0.7),
  rgba(4,9,30,0.7)), url("@/assets/77.jpg");
  background-position: center;
  background-size: cover;
  position: relative;
}

nav{
  display: flex;
  padding: 2% 6%;
  justify-content: space-between;
  align-items: center;
}

nav img{
  width: 100px;
}

.nav-links{
  flex: 1;
  text-align: right;
}

.nav-links ul li{
  list-style: none;
  display: inline-block;
  padding: 8px 12px;
  position: relative;
}

.nav-links ul li a{
  color: antiquewhite;
  text-decoration: none;
  font-size: 13px;
}

.nav-links ul li::after{
  content:'';
  width: 0%;
  height: 2px;
  background: #89c0e3;
  display: block;
  margin: auto;
  transition: 0.5s;
}

.nav-links ul li:hover::after{
  width: 100%;
}

.text-box{
  width: 0%;
  color: aliceblue;
  position: absolute;
  top: 25%;
  left: 40%;
  transform: translate(-50%, -50%);
  text-align: center;
  
  }
  .text-box h1{
    font-size: 62px;
  }

  .text-box p{
    margin: 10px 0 40px;
    font-size: 14px;
    color: aliceblue;
  }

  .hero-btn{
    display: inline-block;
    text-decoration: none;
    color: #dee3e7;
    border: 1px solid #dadee1;
    padding: 12px 34px;
    font-size: 13px;
    background: transparent;
    position: relative;
    cursor: pointer;
  }
  .hero-btn:hover{
    border: #89c0e3;
    background: #89c0e3;
    transform: 2s;
  }

  nav.fa{
    display: block;
    color: #fff;
    margin: 10px;
    font-size: 22px;
    cursor: pointer;
  }

  .nav-links ul{
    padding: 30px;
  }
  @media(max-width: 700px){
      .text-box h1{
        font-size: 20px;
      }
      .nav-links{
        position: absolute;
        background: #89c0e3;
        height: 100vh;
        width: 200px;
        top: 0;
        right: 0;
        text-align: left;
        z-index: 2;

      }
  }

  

.testimonials{
  width: 80%;
  margin: auto;
  padding-top: 100px;
  text-align: center;
}

.testimonial-col{
  flex-basis: 44%;
  border-radius: 10px;
  margin-bottom: 5%;
  text-align: left;
  background: #89c0e3;
  padding: 25%;
  cursor: pointer;
  display: flex;
}

.testimonial-col img{
  height: 40px;
  margin-left: 5px;
  margin-right: 30px;
  border-radius: 50%;
}

.testimonial-col p{
  padding: 0;
}

.testimonial-col h3{
  margin-top: 15px;
  text-align: left;
}


/* fotter*/

.cta{
  margin: 100px auto;
  width: 80%;
  background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url("@/assets/55.jpg") ;
  background-position: center;
  background-size: cover;
  border-radius: 10px;
  text-align: center;
  padding: 100px 0;
}

.cta h1{
  color: #edf0f3;
  margin-bottom: 40px;
  padding: 0;
}

@media(max-width: 700px){
  .cta h1{
    font-size: 24px;
  }
}

.footer{
  margin-top: 150px;
  width: 100%;
  padding: 100px 15%;
  color: #efefef;
  background-color: rgb(43, 38, 38);
  display: flex;
}

.footer div{
  text-align: center;
}

.col-2{
  flex-grow: 2;
}

.footer div h3{
  font-weight: 300;
  margin-bottom: 30px;
  letter-spacing: 1px;
}

.col-1 a{
  display: block;
  text-decoration: none;
  color: #dadee1;
  margin-bottom: 10px;
}

.col-3 a{
  display: block;
  text-decoration: none;
  color: #dadee1;
  margin-bottom: 10px;
}

.col-3 p{
  display: block;
  text-decoration: none;
  color: #dadee1;
  margin-bottom: 10px;
}

form input{
  width: 400px;
  height: 45px;
  border-radius: 4px;
  text-align: center;
  margin-top: 20px;
  margin-bottom: 40px;
  outline: none;
  border: none;
}

form button{
  background: transparent;
  border: 2px solid #fff;
  color: #fff;
  border-radius: 30px;
  padding: 10px 30px;
  font-size: 15px;
  cursor: pointer;
}



.footer h4{
  margin-bottom: 25px;
  margin-top: 25px;
  font-weight: 600;
}

.c{
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
}

iframe{
  width: 100%;
  height: 500px;
  filter: invert(90%);
}

/*them2 herro*/

.herro{
  width: 100%;
  min-height: 100vh;
  padding-left: 12%;
  padding-right: 12%;
  box-sizing: border-box;
  text-align: center;
  color: #fff;
}

.row{
  margin-top: 80px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.col{
  flex-basis: 28%;
  box-sizing: border-box;
  text-align: center;
  position: relative;
  cursor: pointer;
  min-width: 230px;
  margin-bottom: 20px;
}

.profile{
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  background: #1e2648;
  padding: 12px;

}

.profile img{
  width: 100%;
}

.profile h2{
  margin: 25px 0 10px;
  font-weight: 500;
}

.profile p{
  margin-bottom: 10px;
  color: #89c0e3;
}

/* -------------------- Praxis ------------*/

.sub-header{
  height: 50vh;
  width: 100%;
  background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url("@/assets/44.jpg") ;
  background-position: center;
  background-size: cover;
  color: fff;
}

.sub-header h1{
  margin-top: 100px;
}

.about-us{
  width: 80%;
  margin: auto;
  padding-top: 80px;
  padding-bottom: 30px 2px;
}

.a-col img{
  width: 100%;
}

.a-col h1{
  padding-top: 0;
}

.a-col p{
  padding-top: 15px 0 25px;
}

.red-btn{
  border: 1px solid #89c0e3;
  background: transparent;
  color: #25425b;
}

.red-btn:hover{
  color: #fff;
}


.container2{
  margin: 0;
  padding: 0;
  width: 100%;
  min-height: 100vh;
}

.container2 h2{
  color:#89c0e3;
  font-size: 30px;
  padding: 50px 0;
  text-align: center;
}


.price-row{
  width: 90%;
  max-width: 1100px;
  margin: auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));

}

.price-col{
  background: #303756;
  padding: 5% 15%;
  border-radius: 10px;
  color: #dadee1;
  text-align: center;
  margin: 0 10px;
}

.price-col p{
  font-size: 22px;
}

.price-col h3{
  font-size: 44px;
  margin: 20px 0 40px;
  font-weight: 500;
}

.price-col span{
  font-size: 16px;
}

.price-col ul{
  text-align: left;
  margin: 20px 0;
  color: #ddd;
  list-style: none ;
}

.price-col ul li{
  margin: 15px 0;
}

.price-col ul li::before{
content: '.';
color: #25425b;
font-weight: bold;
margin-right: 8px;

}

.price-col button{
  width: 100%;
  padding: 14px 0;
  background: transparent;
  color: #ddd;
  font-size: 15px;
  border: 1px solid #f2f4f9;
  border-radius: 6px;
  margin-top: 30px;
  cursor: pointer;  
}

.price-col button:hover{
  background: #89c0e3;
}

.h{
  width: 80%;
  margin: 100px auto 50px;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  grid-gap: 30px;
}

.h img{
  width: 100%;
  cursor: pointer;
  transition: 0.4s;
}

.h img:hover{
  transform: scale(0.8) rotate(-15deg);
  border-radius: 20px;
  box-shadow: 0 32px 75px rgba(68,77,136,0.2) ;
}

.full-img{
  width: 100%;
  height: 100vh;
  background: rgba(0, 0,0, 0);
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.full-img img{
  width: 90%;
  max-width: 500px;
}

.full-img span{
  position: absolute;
  top: 5%;
  right: 5%;
  font-size: 30px;
  color: #fff;
  cursor: pointer;
}

.t{
  width: 90%;
  max-width: 800px;
  margin: auto;
}

.tt{
  padding: 25%;
  background: #25425b;
  color: #fff;
  width: 100%;
  height: 350px;
  position: relative;
  box-shadow: 0 15px 20px rgba(0,0,0,0.2);
}

.ut{
  width: 80%;
  text-align: center;
  line-height: 30px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  display: none;
}

.ut span{
  display: block;
  font-size: 13px;
  margin-top: 70px;
  font-weight: 500;
  text-transform: uppercase;
}

.pic{
  margin-top: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.user-pic{
  width: 65px;
  padding: 2px;
  border-radius: 80%;
  margin: 10px;
  cursor: pointer;
}

.ut.active-text{
  display: block;
}

.ut.active-text span{
font-size:medium;

}

.user-pic.active-pic{
  width: 100px;
  border: 3px solid #003cff;

}


</style>
